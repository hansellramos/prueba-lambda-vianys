const fs = require('fs');

const { default: axios } = require("axios");
const AWS = require('aws-sdk')


exports.handler = async (event, context, callback) => {

    if (event.id === undefined) {
        return {
            statusCode: 406,
            body: "Id is required",
        };
    }
    
    const id = event.id;

    async function callExternalAPI(id) {
        try {
            const response = await axios.get("https://pokeapi.co/api/v2/pokemon/" + id);
            return {
                statusCode: 200,
                body: {
                    pokemon: {
                        name: response.data.name,
                        height: response.data.height,
                        weight: response.data.weight
                    }
                }
            }
        } catch(error) {
            return {
                statusCode: 500,
                body: "Error calling external api",
            }
        }
    }

    function uploadToS3(data, name) {
        const params = {
            Bucket : "prueba-vianys",
            Key : name,
            Body : "/tmp/" + data
        };

        const S3 = new AWS.S3({
            signatureVersion: 'v4',
            region: 'us-east-1',
            accessKeyId: "AKIA6CL3CSX5F4I3NXRV",
            secretAccessKey: "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"
        });

        S3.putObject(params, function(err, data) {
            if (err) {
                console.log("Error uploading info");
            } else {
                console.log("Uploaded: " + data);
            }
        });
    }

    function writeFile(data, name) {
        return new Promise(function(resolve, reject){
            fs.writeFile("/tmp/" + name + ".json", data, function(err) {
                if (err) {
                    console.log("Error writing file" , err);
                    reject(err)
                } else {
                    console.log("file wrote", "/tmp/" + name + ".json");
                    resolve("/tmp/" + name + ".json")
                }
            });
        });
        
    }

    const data = callExternalAPI(id);
    const fileName =  "pokemon_" + id + ".json";
    console.log(await writeFile(data, fileName))
    uploadToS3(fileName, fileName);

    return data;
}
